package br.com.carstore.Controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.carstore.Car;

@RestController
public class IndexController {
    @GetMapping("/")
    public String index() {
        return "<h1>Hello, Wolrd<h1>";
    }

    public ResponseEntity<Car> home() {
        Car car = new Car();
        car.setName("Fusca");
        car.setColor("Amarelo");

        return ResponseEntity.ok(car);
    }
}
